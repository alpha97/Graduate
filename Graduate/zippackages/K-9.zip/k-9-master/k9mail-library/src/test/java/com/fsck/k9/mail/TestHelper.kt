package com.fsck.k9.mail

fun String.crlf() = replace("\n", "\r\n")
