#if ENABLE_ANTIWORD==1
#include "../include/wordfmt.h"



#endif //ENABLE_ANTIWORD==1


