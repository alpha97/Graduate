#ifndef WORDFMT_H
#define WORDFMT_H
#if ENABLE_ANTIWORD==1

// MS WORD format support using AntiWord library


#endif // ENABLE_ANTIWORD==1
#endif // WORDFMT_H
