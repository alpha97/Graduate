//
// C++ Interface: Jinke/LBook V3 viewer plugin
//
// Description: 
//
//
// Author: Vadim Lopatin <vadim.lopatin@coolreader.org>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//
// cr3jinke.h
#ifndef CR3_JINKE_PLUGIN_H_INCLUDED
#define CR3_JINKE_PLUGIN_H_INCLUDED
#include "jinkeplugin.h"

#endif //CR3_JINKE_PLUGIN_H_INCLUDED
