#ifndef __MOD_CITE_H
#define __MOD_CITE_H 1

#include <cstdlib>
#include <tinydict.h>
#include "lvdocview.h"
#include "crgui.h"

class V3DocViewWin;


extern void
activate_cite(CRGUIWindowManager *wm, V3DocViewWin * mainwin);

#endif
