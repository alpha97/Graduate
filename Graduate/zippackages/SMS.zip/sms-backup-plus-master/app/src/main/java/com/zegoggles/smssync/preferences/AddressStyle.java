package com.zegoggles.smssync.preferences;

public enum AddressStyle {
    NAME,
    NAME_AND_NUMBER,
    NUMBER
}
