package com.zegoggles.smssync.activity.events;

public class AccountAddedEvent {
}
