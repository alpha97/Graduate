package com.zegoggles.smssync.preferences;

public enum MarkAsReadTypes {
    READ,
    UNREAD,
    MESSAGE_STATUS
}
