package com.zegoggles.smssync.compat;

import android.app.Activity;

public class ComposeSmsActivity extends Activity {
}
