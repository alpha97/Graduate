package com.zegoggles.smssync.service.exception;

public class BackupDisabledException extends Exception {
}
