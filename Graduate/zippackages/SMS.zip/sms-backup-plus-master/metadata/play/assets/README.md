## Assets

### sms_512x512.png

Google Play hi-res icon, 512 x 512, 32-bit PNG (with alpha)

### sms_120x120.png

Used in [OAuth consent screen][].

[OAuth consent screen]: https://console.developers.google.com/apis/credentials/consent?project=sms-backup-plus

## Credits

Logo design by Shimon Simon.
