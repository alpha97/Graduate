Before you report your issue, please consider perusing the [https://github.com/jberkel/sms-backup-plus#faq](FAQ) and searching the issues page to see if it has already been reported.

### Expected behaviour

### Actual behaviour

### Steps to reproduce the behaviour

### Please specify the following:

* Android version
* Phone model / brand
* SMS Backup+ version installed
* Messaging app
