This are the svg files of the pictures I use in my app.

I exported these files to png versions and put them in the drawables folder from the app. 

All files are created using Inkscape. If you want to use them, you should use Inkscape too, because Gimp or the default picture viewer from Linux Mint do not display everything like Inkscape does. (For exampe the backgrounds_stacks file)

Cards Abstract:
    https://pixabay.com/en/card-deck-deck-cards-playing-cards-161536/ or
    https://openclipart.org/detail/175269/complete-guyenne-deck

    Downloaded from pixabay, under the CC0 license. 4 color theme was added by me.

Cards Classic:
    https://pixabay.com/en/atlasnye-deck-playing-cards-game-884206/ or
    https://openclipart.org/detail/226207/full-deck-of-ornate-playing-cards

    Downloaded from pixabay, under the CC0 license. Changed the characters of Ace, Joker and Queen.
    4 color theme was added by me.

Cards Modern:
    The theme is available on pixabay.org, but every card as a single file, or
    http://nicubunu.ro/cards/

    Downloaded from pixabay, under the CC0 license. 4 color theme was added by me.

Cards Oxygen Dark/Light:
    https://pixabay.com/en/ace-cards-club-diamond-heart-jack-159857/ 
    https://pixabay.com/en/ace-cards-club-diamond-heart-jack-159856/ or

    https://openclipart.org/detail/171445/oxygen-playing-card-faces
    https://openclipart.org/detail/171444/white-oxygen-playing-card-faces

    Downloaded from pixabay, under the CC0 license. 4 color theme was added by me.

Cards Simple:
    https://pixabay.com/en/pack-of-cards-deck-of-cards-37194/

    Downloaded from pixabay, under the CC0 license. 4 color theme was added by me.

Cards Poker:
    Vectorized Playing Cards 2.0 - http://sourceforge.net/projects/vector-cards/
    Copyright 2015 - Chris Aguilar - conjurenation@gmail.com
    Licensed under LGPL 3 - www.gnu.org/copyleft/lesser.html
    
    Downloaded from sourceforge, under the LGPLv3 license. 4 color theme was added by me.

Cards Basic:
    Created by me from the Ornate theme using Gimp. (Vector version coming soon). Also 
    useable under the CC0 license.

Cards Paris:
    SVG-cards 2.1 - https://sourceforge.net/projects/svg-cards/
    Copyright 2005 - David Berkeley
    Licensed under LGPL 2.1 - https://opensource.org/licenses/LGPL-2.1
    
    Downloaded from sourceforge, under the LGPLv2.1 license. 4 color theme was added by me.

Cards Dondorf:
    Available in the public domain, see here:
    https://git.gnome.org/browse/aisleriot/tree/cards/README.dondorf

    4 color theme was added by me.

Card Backgrounds:

    The first background was created by me, under CC0 license. The other backgrounds are part of the card themes 
    and they are under the same licencse as their original card theme. 4 color theme was added by me.
