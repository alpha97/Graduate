Saved name              Link                                Creator             Original name

card_return             https://freesound.org/s/19244/      deathpie            cardDrop2.wav
card_set                https://freesound.org/s/272434/     ryanharding95       Swipe Card.wav
hint                    https://freesound.org/s/320181/     dland               hint.wav  
deal_cards              https://freesound.org/s/220851/     RobertWulfman       shuffling cards
autocomplete_show       https://freesound.org/s/267528/     syseQ               Good!
win_1                   https://freesound.org/s/258142/     Tuudurt             Level win.wav
win_2                   https://freesound.org/s/215773/     OtisJames           win.wav
win_3                   https://freesound.org/s/339834/     Rocotilos           8-bit "You Win"
win_4                   https://freesound.org/s/333404/     jayfrosting         Cheer 2.wav
background_music_1      https://freesound.org/s/382327/     carpuzi             Background Music Treatment
background_music_2      https://freesound.org/s/81770/      Jonathan Yamoty     10 Dylan's Song.mp3
background_music_3      https://freesound.org/s/21685/      summonhue           04 pollie soft.mp3
background_music_4      https://freesound.org/s/195355/     jmggs@hotmail.com   Music Box
