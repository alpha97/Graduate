package org.wordpress.android.ui.media;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.wordpress.android.R;
import org.wordpress.android.WordPress;
import org.wordpress.android.fluxc.model.MediaModel;
import org.wordpress.android.fluxc.model.MediaModel.MediaUploadState;
import org.wordpress.android.fluxc.model.SiteModel;
import org.wordpress.android.util.AniUtils;
import org.wordpress.android.util.AppLog;
import org.wordpress.android.util.DisplayUtils;
import org.wordpress.android.util.ImageUtils;
import org.wordpress.android.util.ImageUtils.BitmapWorkerCallback;
import org.wordpress.android.util.ImageUtils.BitmapWorkerTask;
import org.wordpress.android.util.MediaUtils;
import org.wordpress.android.util.PhotonUtils;
import org.wordpress.android.util.SiteUtils;
import org.wordpress.android.util.StringUtils;
import org.wordpress.android.util.UrlUtils;
import org.wordpress.android.util.ViewUtils;
import org.wordpress.android.util.WPMediaUtils;
import org.wordpress.android.widgets.WPNetworkImageView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.RejectedExecutionException;

/**
 * An adapter for the media gallery grid.
 */
public class MediaGridAdapter extends RecyclerView.Adapter<MediaGridAdapter.GridViewHolder> {
    private MediaGridAdapterCallback mCallback;
    private final MediaBrowserType mBrowserType;

    private boolean mHasRetrievedAll;
    private boolean mInMultiSelect;
    private boolean mLoadThumbnails = true;

    private final Handler mHandler;
    private final LayoutInflater mInflater;

    private final Context mContext;
    private final SiteModel mSite;

    private final ArrayList<MediaModel> mMediaList = new ArrayList<>();
    private final ArrayList<Integer> mSelectedItems = new ArrayList<>();

    private final int mThumbWidth;
    private final int mThumbHeight;

    private static final float SCALE_NORMAL = 1.0f;
    private static final float SCALE_SELECTED = .8f;

    public interface MediaGridAdapterCallback {
        void onAdapterFetchMoreData();

        void onAdapterItemClicked(int position, boolean isLongClick);

        void onAdapterSelectionCountChanged(int count);

        void onAdapterRequestRetry(int position);

        void onAdapterRequestDelete(int position);
    }

    private static final int INVALID_POSITION = -1;

    public MediaGridAdapter(@NonNull Context context, @NonNull SiteModel site, @NonNull MediaBrowserType browserType) {
        super();
        setHasStableIds(true);

        mContext = context;
        mSite = site;
        mBrowserType = browserType;
        mInflater = LayoutInflater.from(context);
        mHandler = new Handler();

        int displayWidth = DisplayUtils.getDisplayPixelWidth(mContext);
        mThumbWidth = displayWidth / getColumnCount(mContext);
        mThumbHeight = (int) (mThumbWidth * 0.75f);
    }

    @Override
    public long getItemId(int position) {
        return getLocalMediaIdAtPosition(position);
    }

    public void setMediaList(@NonNull List<MediaModel> mediaList) {
        if (!isSameList(mediaList)) {
            mMediaList.clear();
            mMediaList.addAll(mediaList);
            notifyDataSetChanged();
        }
    }

    @Override
    public GridViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.media_grid_item, parent, false);
        return new GridViewHolder(view);
    }

    /*
     * returns the most optimal url to use when retrieving a media image for display here
     */
    private String getBestImageUrl(@NonNull MediaModel media) {
        // return photon-ized url if the site allows it since this gives us the image at the
        // exact size we need here
        if (SiteUtils.isPhotonCapable(mSite)) {
            return PhotonUtils.getPhotonImageUrl(media.getUrl(), mThumbWidth, mThumbHeight);
        }

        // can't use photon, so try the various image sizes - note we favor medium-large and
        // medium because they're more bandwidth-friendly than large
        if (!TextUtils.isEmpty(media.getFileUrlMediumLargeSize())) {
            return media.getFileUrlMediumLargeSize();
        } else if (!TextUtils.isEmpty(media.getFileUrlMediumSize())) {
            return media.getFileUrlMediumSize();
        } else if (!TextUtils.isEmpty(media.getFileUrlLargeSize())) {
            return media.getFileUrlLargeSize();
        }

        // next stop is to return the thumbnail, which will look pixelated in the grid but it's
        // better than eating bandwidth showing the full-sized image
        if (!TextUtils.isEmpty(media.getThumbnailUrl())) {
            return media.getThumbnailUrl();
        }

        // last resort, return the full-sized image url
        return UrlUtils.removeQuery(media.getUrl());
    }

    @Override
    public void onBindViewHolder(GridViewHolder holder, int position) {
        if (!isValidPosition(position)) {
            return;
        }

        MediaModel media = mMediaList.get(position);
        holder.mImageView.setTag(null);

        String strState = media.getUploadState();
        MediaUploadState state = MediaUploadState.fromString(strState);

        boolean isLocalFile = MediaUtils.isLocalFile(strState) && !TextUtils.isEmpty(media.getFilePath());
        boolean isSelected = isItemSelected(media.getId());
        boolean canSelect = canSelectPosition(position);
        boolean isImage = media.getMimeType() != null && media.getMimeType().startsWith("image/");

        if (!mLoadThumbnails) {
            holder.mFileContainer.setVisibility(View.GONE);
            holder.mImageView.setImageUrl(null, WPNetworkImageView.ImageType.PHOTO);
        } else if (isImage) {
            holder.mFileContainer.setVisibility(View.GONE);
            if (isLocalFile) {
                loadLocalImage(media.getFilePath(), holder.mImageView);
            } else {
                holder.mImageView.setImageUrl(getBestImageUrl(media), WPNetworkImageView.ImageType.PHOTO);
            }
        } else if (media.isVideo()) {
            holder.mFileContainer.setVisibility(View.GONE);
            loadVideoThumbnail(media, holder.mImageView);
        } else {
            // not an image or video, so show file name and file type
            holder.mImageView.setImageDrawable(null);
            String fileName = media.getFileName();
            String title = media.getTitle();
            String fileExtension = MediaUtils.getExtensionForMimeType(media.getMimeType());
            holder.mFileContainer.setVisibility(View.VISIBLE);
            holder.mTitleView.setText(TextUtils.isEmpty(title) ? fileName : title);
            holder.mFileTypeView.setText(fileExtension.toUpperCase(Locale.ROOT));
            int placeholderResId = WPMediaUtils.getPlaceholder(fileName);
            holder.mFileTypeImageView.setImageResource(placeholderResId);
        }
        holder.mImageView.setContentDescription(mContext.getString(R.string.media_grid_item_image_desc,
                StringUtils.notNullStr(media.getFileName())));

        if (mBrowserType.canMultiselect() && canSelect) {
            holder.mSelectionCountContainer.setVisibility(View.VISIBLE);
            holder.mSelectionCountTextView.setVisibility(View.VISIBLE);
            holder.mSelectionCountTextView.setSelected(isSelected);
            if (isSelected) {
                int count = mSelectedItems.indexOf(media.getId()) + 1;
                holder.mSelectionCountTextView.setText(String.format(Locale.getDefault(), "%d", count));
            } else {
                holder.mSelectionCountTextView.setText(null);
            }
        } else {
            holder.mSelectionCountContainer.setVisibility(View.GONE);
            holder.mSelectionCountTextView.setVisibility(View.GONE);
        }

        // make sure the thumbnail scale reflects its selection state
        float scale = isSelected ? SCALE_SELECTED : SCALE_NORMAL;
        if (holder.mImageView.getScaleX() != scale) {
            holder.mImageView.setScaleX(scale);
            holder.mImageView.setScaleY(scale);
        }

        // show upload state unless it's already uploaded
        if (state != MediaUploadState.UPLOADED) {
            holder.mStateContainer.setVisibility(View.VISIBLE);

            // only show progress for items currently being uploaded or deleted
            boolean showProgress = state == MediaUploadState.UPLOADING || state == MediaUploadState.DELETING;
            holder.mProgressUpload.setVisibility(showProgress ? View.VISIBLE : View.GONE);

            // failed uploads can be retried or deleted, queued items can be deleted
            if (state == MediaUploadState.FAILED || state == MediaUploadState.QUEUED) {
                holder.mRetryDeleteContainer.setVisibility(View.VISIBLE);
                holder.mImgRetry.setVisibility(state == MediaUploadState.FAILED ? View.VISIBLE : View.GONE);
            } else {
                holder.mRetryDeleteContainer.setVisibility(View.GONE);
            }
            holder.mStateTextView.setText(getLabelForMediaUploadState(state));

            // hide the video player icon so it doesn't overlap state label
            holder.mVideoOverlayContainer.setVisibility(View.GONE);
        } else {
            holder.mStateContainer.setVisibility(View.GONE);
            holder.mStateContainer.setOnClickListener(null);
            holder.mVideoOverlayContainer.setVisibility(media.isVideo() ? View.VISIBLE : View.GONE);
        }

        // if we are near the end, make a call to fetch more
        if (position == getItemCount() - 1
            && !mHasRetrievedAll
            && mCallback != null) {
            mCallback.onAdapterFetchMoreData();
        }
    }

    @Override
    public void onViewRecycled(GridViewHolder holder) {
        super.onViewRecycled(holder);
        holder.mImageView.setImageDrawable(null);
        holder.mImageView.setTag(null);
    }

    public ArrayList<Integer> getSelectedItems() {
        return mSelectedItems;
    }

    public int getSelectedItemCount() {
        return mSelectedItems.size();
    }

    class GridViewHolder extends RecyclerView.ViewHolder {
        private final TextView mTitleView;
        private final WPNetworkImageView mImageView;
        private final TextView mFileTypeView;
        private final ImageView mFileTypeImageView;
        private final TextView mSelectionCountTextView;
        private final TextView mStateTextView;
        private final ProgressBar mProgressUpload;
        private final ViewGroup mStateContainer;
        private final ViewGroup mFileContainer;
        private final ViewGroup mVideoOverlayContainer;
        private final ViewGroup mSelectionCountContainer;
        private final ViewGroup mRetryDeleteContainer;
        private final ImageView mImgRetry;
        private final ImageView mImgTrash;

        GridViewHolder(View view) {
            super(view);

            mImageView = (WPNetworkImageView) view.findViewById(R.id.media_grid_item_image);
            mSelectionCountTextView = (TextView) view.findViewById(R.id.text_selection_count);

            mStateContainer = (ViewGroup) view.findViewById(R.id.media_grid_item_upload_state_container);
            mStateTextView = (TextView) mStateContainer.findViewById(R.id.media_grid_item_upload_state);
            mProgressUpload = (ProgressBar) mStateContainer.findViewById(R.id.media_grid_item_upload_progress);

            mFileContainer = (ViewGroup) view.findViewById(R.id.media_grid_item_file_container);
            mTitleView = (TextView) mFileContainer.findViewById(R.id.media_grid_item_name);
            mFileTypeView = (TextView) mFileContainer.findViewById(R.id.media_grid_item_filetype);
            mFileTypeImageView = (ImageView) mFileContainer.findViewById(R.id.media_grid_item_filetype_image);

            mVideoOverlayContainer = (ViewGroup) view.findViewById(R.id.frame_video_overlay);
            mSelectionCountContainer = (ViewGroup) view.findViewById(R.id.frame_selection_count);

            mImageView.setErrorImageResId(R.drawable.media_item_background);
            mImageView.setDefaultImageResId(R.drawable.media_item_background);

            // make the progress bar white
            mProgressUpload.getIndeterminateDrawable().setColorFilter(Color.WHITE, PorterDuff.Mode.MULTIPLY);

            // set size of image and container views
            mImageView.getLayoutParams().width = mThumbWidth;
            mImageView.getLayoutParams().height = mThumbHeight;
            mStateContainer.getLayoutParams().width = mThumbWidth;
            mStateContainer.getLayoutParams().height = mThumbHeight;
            mFileContainer.getLayoutParams().width = mThumbWidth;
            mFileContainer.getLayoutParams().height = mThumbHeight;

            mRetryDeleteContainer = (ViewGroup) view.findViewById(R.id.container_retry_delete);
            mImgRetry = (ImageView) view.findViewById(R.id.image_retry);
            mImgTrash = (ImageView) view.findViewById(R.id.image_trash);

            itemView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    doAdapterItemClicked(position, false);
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    int position = getAdapterPosition();
                    doAdapterItemClicked(position, true);
                    return true;
                }
            });

            mSelectionCountContainer.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (canSelectPosition(position)) {
                        setInMultiSelect(true);
                        toggleItemSelected(GridViewHolder.this, position);
                    }
                }
            });

            mImgRetry.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (isValidPosition(position) && mCallback != null) {
                        mCallback.onAdapterRequestRetry(position);
                    }
                }
            });

            mImgTrash.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (isValidPosition(position) && mCallback != null) {
                        mCallback.onAdapterRequestDelete(position);
                    }
                }
            });

            ViewUtils.addCircularShadowOutline(mSelectionCountTextView);
        }

        private void doAdapterItemClicked(int position, boolean isLongClick) {
            if (!isValidPosition(position)) {
                return;
            }
            if (isInMultiSelect() && !isLongClick) {
                if (canSelectPosition(position)) {
                    toggleItemSelected(GridViewHolder.this, position);
                }
            } else {
                if (mBrowserType.canMultiselect() && canSelectPosition(position) && !isLongClick) {
                    setInMultiSelect(true);
                    toggleItemSelected(GridViewHolder.this, position);
                }
                if (mCallback != null) {
                    mCallback.onAdapterItemClicked(position, isLongClick);
                }
            }
        }
    }

    public boolean isInMultiSelect() {
        return mInMultiSelect;
    }

    public void setInMultiSelect(boolean value) {
        if (mInMultiSelect != value) {
            mInMultiSelect = value;
            clearSelection();
        }
    }

    private boolean isValidPosition(int position) {
        return position >= 0 && position < getItemCount();
    }

    public int getLocalMediaIdAtPosition(int position) {
        if (isValidPosition(position)) {
            return mMediaList.get(position).getId();
        }
        AppLog.w(AppLog.T.MEDIA, "MediaGridAdapter > Invalid position " + position);
        return INVALID_POSITION;
    }

    /*
     * determines whether the media item at the passed position can be selected - not allowed
     * for local files or deleted items when used as a picker
     */
    private boolean canSelectPosition(int position) {
        if (!isValidPosition(position)) {
            return false;
        }
        if (mBrowserType.isPicker()) {
            MediaModel media = mMediaList.get(position);
            if (MediaUtils.isLocalFile(media.getUploadState())) {
                return false;
            }
            MediaUploadState state = MediaUploadState.fromString(media.getUploadState());
            return state != MediaUploadState.DELETING && state != MediaUploadState.DELETED;
        } else {
            return true;
        }
    }

    private void loadLocalImage(final String filePath, ImageView imageView) {
        imageView.setTag(filePath);

        Bitmap bitmap = WordPress.getBitmapCache().get(filePath);
        if (bitmap != null) {
            imageView.setImageBitmap(bitmap);
        } else {
            imageView.setImageBitmap(null);
            try {
                new BitmapWorkerTask(imageView, mThumbWidth, mThumbHeight, new BitmapWorkerCallback() {
                    @Override
                    public void onBitmapReady(final String path, final ImageView imageView, final Bitmap bitmap) {
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                WordPress.getBitmapCache().put(path, bitmap);
                                if (imageView != null
                                    && imageView.getTag() instanceof String
                                    && ((String) imageView.getTag()).equalsIgnoreCase(path)) {
                                    imageView.setImageBitmap(bitmap);
                                }
                            }
                        });
                    }
                }).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, filePath);
            } catch (RejectedExecutionException e) {
                AppLog.e(AppLog.T.MEDIA, e);
            }
        }
    }

    /*
     * loads the thumbnail for the passed video media item - works with both local and network videos
     */
    private void loadVideoThumbnail(final @NonNull MediaModel media, @NonNull final WPNetworkImageView imageView) {
        // if we have a thumbnail url, use it and be done
        if (!TextUtils.isEmpty(media.getThumbnailUrl())) {
            imageView.setImageUrl(media.getThumbnailUrl(), WPNetworkImageView.ImageType.VIDEO);
            return;
        }

        // thumbnail url is empty, so either this is a local (still uploading) video or the server simply
        // hasn't supplied the thumbnail url
        final String filePath;
        if (!TextUtils.isEmpty(media.getFilePath()) && new File(media.getFilePath()).exists()) {
            filePath = media.getFilePath();
        } else {
            filePath = media.getUrl();
        }

        imageView.setImageUrl(null, WPNetworkImageView.ImageType.NONE);
        imageView.setImageBitmap(null);
        imageView.setTag(filePath);

        if (TextUtils.isEmpty(filePath)) {
            AppLog.w(AppLog.T.MEDIA, "MediaGridAdapter > No path to video thumbnail");
            return;
        }

        // see if we have a cached thumbnail before retrieving it
        Bitmap bitmap = WordPress.getBitmapCache().get(filePath);
        if (bitmap != null) {
            imageView.setImageBitmap(bitmap);
            return;
        }

        new Thread() {
            @Override
            public void run() {
                final Bitmap thumb = ImageUtils.getVideoFrameFromVideo(filePath, mThumbWidth);
                if (thumb != null) {
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            WordPress.getBitmapCache().put(filePath, thumb);
                            if (imageView.getTag() instanceof String
                                && (imageView.getTag()).equals(filePath)) {
                                imageView.setImageBitmap(thumb);
                            }
                        }
                    });
                }
            }
        }.start();
    }

    public boolean isEmpty() {
        return mMediaList.isEmpty();
    }

    @Override
    public int getItemCount() {
        return mMediaList.size();
    }

    public static int getColumnCount(Context context) {
        return DisplayUtils.isLandscape(context) ? 4 : 3;
    }

    public void setCallback(MediaGridAdapterCallback callback) {
        mCallback = callback;
    }

    public void setHasRetrievedAll(boolean b) {
        mHasRetrievedAll = b;
    }

    void setLoadThumbnails(boolean loadThumbnails) {
        if (loadThumbnails != mLoadThumbnails) {
            mLoadThumbnails = loadThumbnails;
            AppLog.d(AppLog.T.MEDIA, "MediaGridAdapter > loadThumbnails = " + loadThumbnails);
            if (mLoadThumbnails) {
                notifyDataSetChanged();
            }
        }
    }

    public void clearSelection() {
        if (mSelectedItems.size() > 0) {
            mSelectedItems.clear();
            notifyDataSetChanged();
        }
    }

    public boolean isItemSelected(int localMediaId) {
        return mSelectedItems.contains(localMediaId);
    }

    public void removeSelectionByLocalId(int localMediaId) {
        if (isItemSelected(localMediaId)) {
            mSelectedItems.remove(Integer.valueOf(localMediaId));
            if (mCallback != null) {
                mCallback.onAdapterSelectionCountChanged(mSelectedItems.size());
            }
            notifyDataSetChanged();
        }
    }

    private void setItemSelectedByPosition(GridViewHolder holder, int position, boolean selected) {
        if (!isValidPosition(position)) {
            return;
        }

        int localMediaId = mMediaList.get(position).getId();
        if (selected) {
            mSelectedItems.add(localMediaId);
        } else {
            mSelectedItems.remove(Integer.valueOf(localMediaId));
        }

        // show and animate the count
        if (selected) {
            holder.mSelectionCountTextView
                    .setText(String.format(Locale.getDefault(), "%d", mSelectedItems.indexOf(localMediaId) + 1));
        } else {
            holder.mSelectionCountTextView.setText(null);
        }
        AniUtils.startAnimation(holder.mSelectionCountContainer, R.anim.pop);
        holder.mSelectionCountTextView.setVisibility(selected ? View.VISIBLE : View.GONE);

        // scale the thumbnail
        if (selected) {
            AniUtils.scale(holder.mImageView, SCALE_NORMAL, SCALE_SELECTED, AniUtils.Duration.SHORT);
        } else {
            AniUtils.scale(holder.mImageView, SCALE_SELECTED, SCALE_NORMAL, AniUtils.Duration.SHORT);
        }

        // redraw after the scale animation completes
        long delayMs = AniUtils.Duration.SHORT.toMillis(mContext);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                notifyDataSetChanged();
            }
        }, delayMs);

        if (mCallback != null) {
            mCallback.onAdapterSelectionCountChanged(mSelectedItems.size());
        }
    }

    private void toggleItemSelected(GridViewHolder holder, int position) {
        if (!isValidPosition(position)) {
            return;
        }
        int localMediaId = mMediaList.get(position).getId();
        boolean isSelected = mSelectedItems.contains(localMediaId);
        setItemSelectedByPosition(holder, position, !isSelected);
    }

    public void setSelectedItems(ArrayList<Integer> selectedItems) {
        mSelectedItems.clear();
        mSelectedItems.addAll(selectedItems);
        if (mCallback != null) {
            mCallback.onAdapterSelectionCountChanged(mSelectedItems.size());
        }
        notifyDataSetChanged();
    }

    private String getLabelForMediaUploadState(MediaUploadState uploadState) {
        switch (uploadState) {
            case QUEUED:
                return mContext.getString(R.string.media_upload_state_queued);
            case UPLOADING:
                return mContext.getString(R.string.media_upload_state_uploading);
            case DELETING:
                return mContext.getString(R.string.media_upload_state_deleting);
            case DELETED:
                return mContext.getString(R.string.media_upload_state_deleted);
            case FAILED:
                return mContext.getString(R.string.media_upload_state_failed);
            case UPLOADED:
                return mContext.getString(R.string.media_upload_state_uploaded);
        }
        return "";
    }

    void updateMediaItem(@NonNull MediaModel media, boolean forceUpdate) {
        int index = indexOfMedia(media);
        if (index > -1 && (forceUpdate || !media.equals(mMediaList.get(index)))) {
            mMediaList.set(index, media);
            notifyItemChanged(index);
        }
    }

    void removeMediaItem(@NonNull MediaModel media) {
        int index = indexOfMedia(media);
        if (index > -1) {
            mMediaList.remove(index);
            notifyItemRemoved(index);
        }
    }

    boolean mediaExists(@NonNull MediaModel media) {
        return indexOfMedia(media) > -1;
    }

    private int indexOfMedia(@NonNull MediaModel media) {
        for (int i = 0; i < mMediaList.size(); i++) {
            if (media.getId() == mMediaList.get(i).getId()) {
                return i;
            }
        }
        return -1;
    }

    /*
     * returns true if the passed list is the same as the existing one
     */
    private boolean isSameList(@NonNull List<MediaModel> otherList) {
        if (otherList.size() != mMediaList.size()) {
            return false;
        }

        for (MediaModel otherMedia : otherList) {
            if (!mediaExists(otherMedia)) {
                return false;
            }
        }

        return true;
    }
}
