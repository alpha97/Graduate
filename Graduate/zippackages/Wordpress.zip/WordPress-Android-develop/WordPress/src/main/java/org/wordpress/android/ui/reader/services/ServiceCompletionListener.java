package org.wordpress.android.ui.reader.services;

public interface ServiceCompletionListener {
    void onCompleted(Object companion);
}
