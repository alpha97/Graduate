presage-lib-x.y.z-obfuscated-modified.jar - Removes AlarmReceiver.class to avoid ANR
presage-lib-x.y.z-obfuscated.jar.bak - Original .jar, renamed to .bak so it's not picked up
