/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.totsp.crossword.web.client.rebind;

import com.totsp.crossword.web.client.WASDCodes;

/**
 *
 * @author kebernet
 */
public class WASDCodesSafari extends WASDCodes {

    @Override
     public int w(){
        return 23;
    }

    @Override
    public int a(){
        return 1;
    }

    @Override
    public int s(){
        return 19;
    }

    @Override
    public int d(){
        return 4;
    }




}
