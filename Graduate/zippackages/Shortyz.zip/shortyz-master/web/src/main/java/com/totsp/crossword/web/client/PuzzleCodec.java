/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.totsp.crossword.web.client;

import com.totsp.crossword.puz.Puzzle;
import com.totsp.gwittir.serial.json.client.JSONCodec;

/**
 *
 * @author kebernet
 */
public interface PuzzleCodec extends JSONCodec<Puzzle> {

}
