/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.totsp.crossword.web.client;

/**
 *
 * @author kebernet
 */
public class WASDCodes {

  public int w(){
       return 119;
   }

   public int a(){
       return 97;
   }

   public int s(){
       return 115;
   }

   public int d(){
       return 100;
   }


}
