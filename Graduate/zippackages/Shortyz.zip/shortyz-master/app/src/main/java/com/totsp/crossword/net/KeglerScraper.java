package com.totsp.crossword.net;


//http://www.lafn.org/~keglerron/Block_style/index.html
public class KeglerScraper extends AbstractPageScraper {
    public KeglerScraper() {
        super("http://www.lafn.org/~keglerron/Block_style/index.html", "Kegler's Kryptics");
    }
}
