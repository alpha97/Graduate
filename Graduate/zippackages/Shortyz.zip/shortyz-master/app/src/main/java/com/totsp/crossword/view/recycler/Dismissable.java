package com.totsp.crossword.view.recycler;

/**
 * Created by rcooper on 7/23/15.
 */
public interface Dismissable {

    void onItemDismiss(int position);
}
