package com.totsp.crossword.net;

public class BEQuigleyScraper extends AbstractPageScraper {
    public BEQuigleyScraper() {
        super("http://www.fleetwoodwack.typepad.com/", "Brendan Emmett Quigley");
    }
}
