package com.totsp.crossword.net;

public class CruScraper extends AbstractPageScraper {
    public CruScraper() {
        super("http://world.std.com/~wij/puzzles/cru/", "Cryptic Cru Workshop Archive");
    }
}
