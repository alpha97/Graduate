package com.totsp.crossword.firstrun;

import android.support.v4.app.Fragment;
import android.view.View;

/**
 *
 * Created by rcooper on 6/28/15.
 */
public class SlideFragment extends Fragment {

    protected View thisView;


    public void initView(View v){
        thisView = v;
    }

    @Override
    public void onResume() {
        super.onResume();
    }


}
